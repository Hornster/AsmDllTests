#pragma once

extern "C" __declspec(dllexport) int __stdcall callFoo();
extern "C" int __stdcall foo();